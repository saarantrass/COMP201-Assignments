In this lab assignment you are required to complete the main.c file, there are three functions that you need to implement as instructed in the comments.

Good luck!
